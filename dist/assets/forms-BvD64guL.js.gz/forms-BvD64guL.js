import"./vendor-a6qBUclc.js";
