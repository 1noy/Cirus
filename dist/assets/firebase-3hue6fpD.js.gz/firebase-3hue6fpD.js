import{r as a,o as e,q as s,t as r,a as t}from"./firebase-auth-Dy6ffJkg.js";import{f as i}from"./firebase-firestore-_jyfTNsQ.js";import{a as o}from"./firebase-storage-BIx4hGas.js";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
a("firebase","12.0.0","app");const n={apiKey:"AIzaSyDW3ze_OVVjr5I79e0zqDbvnOUi2YRnPFA",authDomain:"chat-changing.firebaseapp.com",projectId:"chat-changing",storageBucket:"chat-changing.appspot.com",messagingSenderId:"38586122759",appId:"1:38586122759:web:07e8309564df8ce71aa0a2",measurementId:"G-NTW1DN98K3"};let p;try{p=0===s().length?r(n):t()}catch(g){throw new Error("Impossible d'initialiser Firebase")}const c=e(p),m=i(p),f=o(p);export{c as a,m as d,f as s};
