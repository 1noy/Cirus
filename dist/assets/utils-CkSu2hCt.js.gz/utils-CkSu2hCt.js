function t(e,o){return(t=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(t,e){return t.__proto__=e,t})(e,o)}export{t as _};
